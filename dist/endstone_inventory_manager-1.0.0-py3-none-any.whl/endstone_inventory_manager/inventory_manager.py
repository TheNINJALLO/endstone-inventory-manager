from endstone.plugin import Plugin
from endstone.command import Command, CommandSender
from endstone.event import event_handler, PlayerJoinEvent, PlayerQuitEvent
from endstone.form import ActionForm, MessageForm, ModalForm, TextInput
from endstone import Player
from endstone.inventory import ItemStack
import os
import time
import json
from pathlib import Path
from .db_util import (
    InventoryDB, deserialize_item, serialize_item,
    get_item_display_info, extract_shulker_contents,
)

# Try to import ChestForm for visual inventory display
try:
    from chest_form_api_endstone import ChestForm
    CHEST_FORM_AVAILABLE = True
except ImportError:
    CHEST_FORM_AVAILABLE = False

# NBT classes for shulker content reading
try:
    from endstone.nbt import CompoundTag
except (ImportError, AttributeError):
    from endstone import CompoundTag


# ──────────────────────────────────────────────────────────────────────
# ENCHANTMENT NAME MAPPING (API 0.11 string-based IDs)
# ──────────────────────────────────────────────────────────────────────

ENCHANT_NAMES = {
    "minecraft:protection": "Protection",
    "minecraft:fire_protection": "Fire Protection",
    "minecraft:feather_falling": "Feather Falling",
    "minecraft:blast_protection": "Blast Protection",
    "minecraft:projectile_protection": "Projectile Protection",
    "minecraft:thorns": "Thorns",
    "minecraft:respiration": "Respiration",
    "minecraft:depth_strider": "Depth Strider",
    "minecraft:aqua_affinity": "Aqua Affinity",
    "minecraft:sharpness": "Sharpness",
    "minecraft:smite": "Smite",
    "minecraft:bane_of_arthropods": "Bane of Arthropods",
    "minecraft:knockback": "Knockback",
    "minecraft:fire_aspect": "Fire Aspect",
    "minecraft:looting": "Looting",
    "minecraft:efficiency": "Efficiency",
    "minecraft:silk_touch": "Silk Touch",
    "minecraft:unbreaking": "Unbreaking",
    "minecraft:fortune": "Fortune",
    "minecraft:power": "Power",
    "minecraft:punch": "Punch",
    "minecraft:flame": "Flame",
    "minecraft:infinity": "Infinity",
    "minecraft:luck_of_the_sea": "Luck of the Sea",
    "minecraft:lure": "Lure",
    "minecraft:frost_walker": "Frost Walker",
    "minecraft:mending": "Mending",
    "minecraft:binding": "Curse of Binding",
    "minecraft:vanishing": "Curse of Vanishing",
    "minecraft:impaling": "Impaling",
    "minecraft:riptide": "Riptide",
    "minecraft:loyalty": "Loyalty",
    "minecraft:channeling": "Channeling",
    "minecraft:multishot": "Multishot",
    "minecraft:piercing": "Piercing",
    "minecraft:quick_charge": "Quick Charge",
    "minecraft:soul_speed": "Soul Speed",
    "minecraft:swift_sneak": "Swift Sneak",
    "minecraft:wind_burst": "Wind Burst",
    "minecraft:density": "Density",
    "minecraft:breach": "Breach",
}

# Legacy numeric ID → string ID mapping (for DB compatibility)
_LEGACY_ENCHANT_IDS = {
    0: "minecraft:protection", 1: "minecraft:fire_protection",
    2: "minecraft:feather_falling", 3: "minecraft:blast_protection",
    4: "minecraft:projectile_protection", 5: "minecraft:thorns",
    6: "minecraft:respiration", 7: "minecraft:depth_strider",
    8: "minecraft:aqua_affinity", 9: "minecraft:sharpness",
    10: "minecraft:smite", 11: "minecraft:bane_of_arthropods",
    12: "minecraft:knockback", 13: "minecraft:fire_aspect",
    14: "minecraft:looting", 15: "minecraft:efficiency",
    16: "minecraft:silk_touch", 17: "minecraft:unbreaking",
    18: "minecraft:fortune", 19: "minecraft:power",
    20: "minecraft:punch", 21: "minecraft:flame",
    22: "minecraft:infinity", 23: "minecraft:luck_of_the_sea",
    24: "minecraft:lure", 25: "minecraft:frost_walker",
    26: "minecraft:mending", 27: "minecraft:binding",
    28: "minecraft:vanishing", 29: "minecraft:impaling",
    30: "minecraft:riptide", 31: "minecraft:loyalty",
    32: "minecraft:channeling", 33: "minecraft:multishot",
    34: "minecraft:piercing", 35: "minecraft:quick_charge",
    36: "minecraft:soul_speed", 37: "minecraft:swift_sneak",
    38: "minecraft:wind_burst", 39: "minecraft:density",
    40: "minecraft:breach",
}

ROMAN_NUMERALS = {1: "I", 2: "II", 3: "III", 4: "IV", 5: "V",
                  6: "VI", 7: "VII", 8: "VIII", 9: "IX", 10: "X"}


def enchant_display(ench, lvl: int) -> str:
    """Format an enchantment (Enchantment object, string ID, or numeric ID) + level into a readable string"""
    if hasattr(ench, 'id'):
        ench_id = ench.id
    elif isinstance(ench, int):
        ench_id = _LEGACY_ENCHANT_IDS.get(ench, f"minecraft:unknown_{ench}")
    else:
        ench_id = str(ench)
    name = ENCHANT_NAMES.get(ench_id, ench_id.replace("minecraft:", "").replace("_", " ").title())
    level_str = ROMAN_NUMERALS.get(lvl, str(lvl))
    return f"§b✦ {name} {level_str}"


# ──────────────────────────────────────────────────────────────────────
# HELPER FUNCTIONS
# ──────────────────────────────────────────────────────────────────────

def online_players(plugin: Plugin):
    """Get all online players from the server"""
    return plugin.server.online_players


def player_name(player: Player) -> str:
    """Get player's display name"""
    return player.name


def get_inventory(player: Player):
    """Get player's main inventory"""
    try:
        return player.inventory
    except AttributeError:
        return None


def get_ender(player: Player):
    """Get player's ender chest inventory"""
    try:
        return player.ender_chest
    except AttributeError:
        return None


def inv_size(inventory) -> int:
    """Get inventory size"""
    try:
        return inventory.size
    except AttributeError:
        return 0


def get_item_from_slot(inventory, slot: int):
    """Get item from inventory slot"""
    try:
        return inventory.get_item(slot)
    except (AttributeError, IndexError):
        return None


def is_air(item) -> bool:
    """Check if item is air/empty"""
    if item is None:
        return True
    try:
        item_type = str(item.type).lower()
        return item_type in ["air", "minecraft:air"] or item.amount == 0
    except AttributeError:
        return True


def item_display_name(item) -> str:
    """Get item display name using ItemMeta (API 0.11)"""
    try:
        meta = item.item_meta
        if meta is not None and meta.has_display_name:
            return meta.display_name
    except Exception:
        pass
    try:
        if hasattr(item, 'type'):
            return str(item.type).replace("minecraft:", "").replace("_", " ").title()
    except Exception:
        pass
    return "Unknown Item"


def get_enchants_from_item(item) -> list:
    """Extract enchantments from a live ItemStack using ItemMeta (API 0.11).
    Returns list of (Enchantment, level) tuples."""
    enchants = []
    try:
        meta = item.item_meta
        if meta is not None and meta.has_enchants:
            for ench_obj, level in meta.enchants.items():
                enchants.append((ench_obj, level))
    except Exception:
        pass
    return enchants


def get_shulker_contents_from_item(item, logger=None) -> list:
    """Extract shulker box contents from a live ItemStack's NBT.
    Returns a list of dicts with 'name' and 'count' for each contained item.
    Note: Uses raw NBT since ItemMeta does not expose block entity contents."""
    contents = []
    try:
        nbt = getattr(item, 'nbt', None)
        if nbt is None:
            if logger:
                logger.warning("[ShulkerDebug] item.nbt is None — no NBT data on this shulker")
            return contents

        # Debug: dump all top-level NBT keys and sub-keys
        if logger:
            try:
                keys = list(nbt.keys()) if hasattr(nbt, 'keys') else []
                logger.info(f"[ShulkerDebug] Top-level NBT keys: {keys}")
                for k in keys:
                    sub = nbt.get(k)
                    sub_type = type(sub).__name__
                    if hasattr(sub, 'keys'):
                        sub_keys = list(sub.keys())
                        logger.info(f"[ShulkerDebug]   '{k}' ({sub_type}) -> sub-keys: {sub_keys}")
                        # Go one level deeper for compound tags
                        for sk in sub_keys:
                            ssub = sub.get(sk)
                            ssub_type = type(ssub).__name__
                            if hasattr(ssub, 'keys'):
                                logger.info(f"[ShulkerDebug]     '{k}.{sk}' ({ssub_type}) -> sub-keys: {list(ssub.keys())}")
                            elif hasattr(ssub, 'size'):
                                logger.info(f"[ShulkerDebug]     '{k}.{sk}' ({ssub_type}) -> list size: {ssub.size()}")
                            else:
                                val = getattr(ssub, 'value', ssub)
                                logger.info(f"[ShulkerDebug]     '{k}.{sk}' ({ssub_type}) -> value: {val}")
                    elif hasattr(sub, 'size'):
                        logger.info(f"[ShulkerDebug]   '{k}' ({sub_type}) -> list size: {sub.size()}")
                    else:
                        val = getattr(sub, 'value', sub)
                        logger.info(f"[ShulkerDebug]   '{k}' ({sub_type}) -> value: {val}")
            except Exception as dbg_e:
                logger.warning(f"[ShulkerDebug] Error dumping NBT keys: {dbg_e}")

        # Bedrock stores shulker contents under different NBT paths depending on version:
        #   - BlockEntityTag > Items  (most common in Bedrock)
        #   - tag > Items             (alternative)
        #   - Items                   (direct, less common)
        items_tag = None
        for parent_key in ("BlockEntityTag", "tag"):
            parent = nbt.get(parent_key)
            if parent is not None:
                items_tag = parent.get("Items")
                if items_tag is not None:
                    if logger:
                        logger.info(f"[ShulkerDebug] Found Items under '{parent_key}', size={items_tag.size()}")
                    break
        if items_tag is None:
            items_tag = nbt.get("Items")
            if items_tag is not None and logger:
                logger.info(f"[ShulkerDebug] Found Items at root, size={items_tag.size()}")
        if items_tag is None:
            if logger:
                logger.warning("[ShulkerDebug] No 'Items' tag found anywhere in NBT")
            return contents

        for i in range(items_tag.size()):
            entry = items_tag[i]
            # Bedrock uses "Name" or "id" for the item identifier
            name_tag = entry.get("Name")
            if name_tag is None:
                name_tag = entry.get("id")
            count_tag = entry.get("Count")
            item_name = ""
            if name_tag is not None:
                item_name = str(name_tag.value) if hasattr(name_tag, 'value') else str(name_tag)
            if not item_name:
                continue
            clean_name = item_name.replace("minecraft:", "").replace("_", " ").title()
            count = int(count_tag.value) if count_tag and hasattr(count_tag, 'value') else 1
            # Also extract enchantments for contained items
            contained_enchants = []
            try:
                tag_tag = entry.get("tag")
                if tag_tag is not None:
                    ench_tag = tag_tag.get("ench")
                    if ench_tag is not None:
                        for j in range(ench_tag.size()):
                            e = ench_tag[j]
                            eid_tag = e.get("id")
                            elvl_tag = e.get("lvl")
                            eid = int(eid_tag.value) if eid_tag and hasattr(eid_tag, 'value') else 0
                            elvl = int(elvl_tag.value) if elvl_tag and hasattr(elvl_tag, 'value') else 1
                            ench_str_id = _LEGACY_ENCHANT_IDS.get(eid, f"Ench {eid}")
                            ench_name = ENCHANT_NAMES.get(ench_str_id, ench_str_id.replace("minecraft:", "").replace("_", " ").title())
                            contained_enchants.append(f"{ench_name} {ROMAN_NUMERALS.get(elvl, str(elvl))}")
            except Exception:
                pass
            entry_data = {"name": clean_name, "count": count}
            if contained_enchants:
                entry_data["enchants"] = contained_enchants
            contents.append(entry_data)
    except Exception:
        pass
    return contents


def get_damage_from_item(item) -> int:
    """Get damage value from item using ItemMeta (API 0.11)"""
    try:
        meta = item.item_meta
        if meta is not None and meta.has_damage:
            return meta.damage
    except Exception:
        pass
    return 0


def build_rich_lore(item) -> list:
    """Build rich lore lines for an item, including enchantments, durability, and shulker contents.
    Uses ItemMeta (API 0.11) for lore, enchants, damage, repair cost, unbreakable."""
    lore = []
    item_type = str(item.type).lower() if hasattr(item, 'type') else ""

    # Get existing lore from ItemMeta
    try:
        meta = item.item_meta
        if meta is not None and meta.has_lore:
            lore.extend(meta.lore)
    except Exception:
        pass

    # Add enchantment lines
    enchants = get_enchants_from_item(item)
    if enchants:
        if lore:
            lore.append("")  # Separator
        for ench_obj, elvl in enchants:
            lore.append(enchant_display(ench_obj, elvl))

    # Add damage/durability info
    damage = get_damage_from_item(item)
    if damage > 0:
        lore.append(f"§7Damage: §c{damage}")

    # Add repair cost info
    try:
        meta = item.item_meta
        if meta is not None:
            if meta.has_repair_cost and meta.repair_cost > 0:
                lore.append(f"§7Repair Cost: §e{meta.repair_cost}")
            if meta.is_unbreakable:
                lore.append("§9✦ Unbreakable")
    except Exception:
        pass

    # Add shulker indicator (live NBT not available in Endstone 0.11, so show hint)
    if "shulker" in item_type:
        lore.append("§d📦 Shulker Box §7- Click to inspect")

    return lore


def add_item(inventory, item) -> bool:
    """Add item to inventory, returns True if successful"""
    try:
        result = inventory.add_item(item)
        return not result or len(result) == 0
    except (AttributeError, Exception):
        return False


def set_item_in_slot(inventory, slot: int, item) -> bool:
    """Set item in specific slot, returns True if successful"""
    try:
        inventory.set_item(slot, item)
        return True
    except (AttributeError, IndexError, Exception):
        return False


def build_rich_lore_from_db(item_data: dict) -> list:
    """Build rich lore for offline items from serialized NBT dict data."""
    lore = []
    info = get_item_display_info(item_data)
    item_type = info.get("type", "")

    # Existing lore
    existing_lore = info.get("lore", [])
    if existing_lore:
        lore.extend(existing_lore)

    # Enchantments from DB data (uses legacy numeric IDs)
    enchants = info.get("enchants", {})
    if enchants:
        if lore:
            lore.append("")
        for ench_key, lvl in enchants.items():
            try:
                eid = int(ench_key.replace("Enchantment ", ""))
                ench_str_id = _LEGACY_ENCHANT_IDS.get(eid, f"minecraft:unknown_{eid}")
            except (ValueError, AttributeError):
                ench_str_id = str(ench_key)
            lore.append(enchant_display(ench_str_id, lvl))

    # Damage
    damage = info.get("damage", 0)
    if damage > 0:
        lore.append(f"§7Damage: §c{damage}")

    # Shulker contents
    if "shulker" in item_type.lower():
        contents = extract_shulker_contents(item_data)
        if contents:
            lore.append("§d─── Contents ───")
            for i, entry in enumerate(contents[:8]):
                lore.append(f"§7• {entry['name']} ×{entry['count']}")
            if len(contents) > 8:
                lore.append(f"§8... and {len(contents) - 8} more")
        else:
            lore.append("§7(Empty Shulker)")

    return lore


# ──────────────────────────────────────────────────────────────────────
# MAIN PLUGIN CLASS
# ──────────────────────────────────────────────────────────────────────

class InventoryManagerPlugin(Plugin):
    api_version = "0.11"

    commands = {
        "manageinv": {
            "description": "Open inventory management interface",
            "usages": ["/manageinv"],
            "permissions": ["inventory_manager.use"]
        }
    }

    permissions = {
        "inventory_manager.use": {
            "description": "Allows using the inventory manager",
            "default": "op"
        }
    }

    def on_enable(self) -> None:
        """Called when plugin is enabled"""
        self.logger.info("Inventory Manager Plugin v1.0.0 enabled!")
        self.logger.info(f"ChestForm available: {CHEST_FORM_AVAILABLE}")

        # Initialize database
        try:
            self.db = InventoryDB()
            self.logger.info("Database initialized successfully")
        except Exception as e:
            self.logger.error(f"Failed to initialize database: {e}")
            self.db = None

        if CHEST_FORM_AVAILABLE:
            self.logger.info("Visual inventory display is ENABLED (ChestForm)")
        else:
            self.logger.warning("Visual display DISABLED - install chest_form_api_endstone")

        self.register_events(self)

        # Start periodic auto-save for ender chests (every 5 minutes = 6000 ticks)
        self._start_autosave_task()

    def on_disable(self) -> None:
        """Called when plugin is disabled"""
        if hasattr(self, '_autosave_task') and self._autosave_task:
            try:
                self._autosave_task.cancel()
            except:
                pass

        self._save_all_enderchests()

        if hasattr(self, 'db') and self.db:
            try:
                self.db.close()
                self.logger.info("Database connection closed")
            except Exception as e:
                self.logger.error(f"Error closing database: {e}")

        self.logger.info("Inventory Manager Plugin disabled!")

    def _start_autosave_task(self):
        """Start the periodic ender chest auto-save task"""
        if not hasattr(self, 'db') or not self.db:
            return

        autosave_interval = 6000  # 5 minutes in ticks

        def autosave_callback():
            self._save_all_enderchests()
            self._autosave_task = self.server.scheduler.run_task(
                self, autosave_callback, delay=autosave_interval
            )

        self._autosave_task = self.server.scheduler.run_task(
            self, autosave_callback, delay=autosave_interval
        )
        self.logger.info("Ender chest auto-save enabled (every 5 minutes)")

    def _save_all_enderchests(self):
        """Save ender chests for all online players"""
        if not hasattr(self, 'db') or not self.db:
            return

        saved_count = 0
        for player in self.server.online_players:
            try:
                self.db.save_user(player, int(time.time()))
                self.db.save_enderchest(player)
                saved_count += 1
            except Exception as e:
                self.logger.warning(f"Failed to auto-save ender chest for {player.name}: {e}")

        if saved_count > 0:
            self.logger.debug(f"Auto-saved ender chests for {saved_count} player(s)")

    def on_command(self, sender: CommandSender, command: Command, args: list[str]) -> bool:
        """Handle commands"""
        if command.name == "manageinv":
            if not isinstance(sender, Player):
                sender.send_error_message("This command can only be used by players!")
                return True

            if not sender.has_permission("inventory_manager.use"):
                sender.send_error_message("§cYou don't have permission to use this command!")
                return True

            self.open(sender)
            return True

        return False

    # ──────────────────────────────────────────────────────────────────────
    # EVENT HANDLERS
    # ──────────────────────────────────────────────────────────────────────

    @event_handler
    def on_player_join(self, event: PlayerJoinEvent):
        """Handle player join - save user info to database"""
        if not hasattr(self, 'db') or not self.db:
            return
        try:
            player = event.player
            join_time = int(time.time())
            self.db.save_user(player, join_time)
            self.logger.debug(f"Saved user info for {player.name} (XUID: {player.xuid})")
        except Exception as e:
            self.logger.error(f"Failed to save user info on join: {e}")

    @event_handler
    def on_player_quit(self, event: PlayerQuitEvent):
        """Handle player quit - save inventory and ender chest to database"""
        if not hasattr(self, 'db') or not self.db:
            return
        try:
            player = event.player
            leave_time = int(time.time())
            self.db.update_user_leave_time(player.xuid, leave_time)
            self.db.save_inventory(player)
            self.db.save_enderchest(player)
            self.logger.debug(f"Saved inventory + ender chest for {player.name}")
        except Exception as e:
            self.logger.error(f"Failed to save player data on quit: {e}")

    # ──────────────────────────────────────────────────────────────────────
    # MAIN MENU
    # ──────────────────────────────────────────────────────────────────────

    def open(self, player: Player):
        """Open the main inventory manager menu"""
        form = ActionForm(
            title="§l§6Inventory Manager",
            content="§7Manage player inventories"
        )
        form.add_button("§aOnline Players")
        form.add_button("§eOffline Players §7(Ender Chest Only)")
        form.add_button("§cClose")

        def on_submit(pl, idx):
            if idx == 0:
                return self._pick_online_player(pl)
            elif idx == 1:
                return self._pick_offline_player(pl)

        form.on_submit = on_submit
        player.send_form(form)

    # ──────────────────────────────────────────────────────────────────────
    # ONLINE INVENTORIES FLOW
    # ──────────────────────────────────────────────────────────────────────

    def _pick_online_player(self, p: Player):
        opls = online_players(self)
        names = [player_name(pl) for pl in opls]

        if not names:
            p.send_message("§7No players online.")
            return self.open(p)

        form = ActionForm(title="§lOnline Players", content="Pick a player")
        for n in names:
            form.add_button(n)
        form.add_button("Back")

        def on_submit(pl, idx):
            if idx is None or idx < 0 or idx >= len(names):
                return self.open(pl)
            target = None
            for live in online_players(self):
                if player_name(live) == names[idx]:
                    target = live
                    break
            if not target:
                pl.send_message("§7Player went offline.")
                return self._pick_online_player(pl)
            return self._inspect_online_player(pl, target)

        form.on_submit = on_submit
        p.send_form(form)

    def _inspect_online_player(self, viewer: Player, target: Player):
        """Main inspection menu - choose between Inventory or Ender Chest"""
        tname = player_name(target)
        form = ActionForm(
            title=f"§lInspect: {tname}",
            content="Choose what to inspect:"
        )
        form.add_button("§6Inventory")       # 0
        form.add_button("§dEnder Chest")     # 1
        form.add_button("Back")              # 2

        def pick(pl, idx):
            if idx == 0:
                return self._container_view_options(pl, target, "inv")
            elif idx == 1:
                return self._container_view_options(pl, target, "ender")
            else:
                return self._pick_online_player(pl)

        form.on_submit = pick
        viewer.send_form(form)

    def _container_view_options(self, viewer: Player, target: Player, which: str):
        """Sub-menu for Inventory/Ender Chest viewing options"""
        tname = player_name(target)
        label = "Inventory" if which == "inv" else "Ender Chest"
        form = ActionForm(
            title=f"§l{tname}'s {label}",
            content=(
                "§eList View§r - Text list with Take/Copy/Remove actions\n"
                "§bChest View§r - Visual chest display + item actions"
            )
        )
        form.add_button("§eList View")  # 0

        if CHEST_FORM_AVAILABLE:
            form.add_button("§bChest View + Actions")  # 1
            form.add_button("« Back")                   # 2
        else:
            form.add_button("« Back")                   # 1

        def pick(pl, idx):
            if idx == 0:
                return self._open_container(pl, target, which)
            elif idx == 1:
                if CHEST_FORM_AVAILABLE:
                    return self._show_chest_then_actions(pl, target, which)
                else:
                    return self._inspect_online_player(pl, target)
            else:
                return self._inspect_online_player(pl, target)

        form.on_submit = pick
        viewer.send_form(form)

    # ──────────────────────────────────────────────────────────────────────
    # LIST VIEW (with inline actions)
    # ──────────────────────────────────────────────────────────────────────

    def _open_container(self, viewer: Player, target: Player, which: str):
        """Show inventory/ender chest as list with item actions"""
        tname = player_name(target)
        if which == "inv":
            inv = get_inventory(target)
            title = "Inventory"
        else:
            inv = get_ender(target)
            title = "Ender Chest"

        if not inv:
            viewer.send_message(f"§cCan't read {title.lower()} on this build.")
            return self._inspect_online_player(viewer, target)

        size = inv_size(inv)
        form = ActionForm(title=f"{title}: {tname}", content=f"{size} slots")
        for i in range(size):
            it = get_item_from_slot(inv, i)
            if not it or is_air(it):
                form.add_button(f"[{i}] — empty —")
            else:
                name = item_display_name(it)
                cnt = getattr(it, "amount", 1)
                item_type = str(it.type).lower()

                # Show enchant count and shulker info inline
                enchants = get_enchants_from_item(it)
                ench_tag = f" §b({len(enchants)} ench)" if enchants else ""

                if "shulker" in item_type:
                    form.add_button(f"[{i}] §d📦 {name} ×{cnt}{ench_tag}")
                else:
                    form.add_button(f"[{i}] {name} ×{cnt}{ench_tag}")
        form.add_button("« Back to Player")

        def pick(pl, idx):
            if idx == size:
                return self._inspect_online_player(pl, target)
            if idx is None or idx < 0 or idx >= size:
                return self._inspect_online_player(pl, target)
            return self._slot_actions(pl, target, inv, idx, title)

        form.on_submit = pick
        viewer.send_form(form)

    def _slot_actions(self, viewer: Player, target: Player, inv, slot_idx: int, title: str):
        """Show actions for a specific inventory slot with full item details"""
        it = get_item_from_slot(inv, slot_idx)
        which = "inv" if title == "Inventory" else "ender"

        if not it or is_air(it):
            viewer.send_message("§7That slot is empty.")
            return self._open_container(viewer, target, which)

        name = item_display_name(it)
        cnt = getattr(it, "amount", 1)
        item_type = str(it.type).lower()

        # Build detailed content
        content = f"§l{name}§r ×{cnt}\n§7Type: §f{item_type}"

        # Show enchantments
        enchants = get_enchants_from_item(it)
        if enchants:
            content += "\n\n§6Enchantments:"
            for ench_obj, elvl in enchants:
                content += f"\n  {enchant_display(ench_obj, elvl)}"

        # Show damage
        damage = get_damage_from_item(it)
        if damage > 0:
            content += f"\n§7Damage: §c{damage}"

        # Show repair cost and unbreakable
        try:
            meta = it.item_meta
            if meta is not None:
                if meta.has_repair_cost and meta.repair_cost > 0:
                    content += f"\n§7Repair Cost: §e{meta.repair_cost}"
                if meta.is_unbreakable:
                    content += "\n§9✦ Unbreakable"
        except Exception:
            pass

        # Shulker indicator
        if "shulker" in item_type:
            content += "\n\n§d📦 Shulker Box"
            content += "\n§7Contents can be viewed by placing the shulker in-game."

        f = ActionForm(title=f"{title} [{slot_idx}]", content=content)
        f.add_button("§aTake (move to me)")    # 0
        f.add_button("§bCopy to me")           # 1
        f.add_button("§cRemove (clear slot)")  # 2
        f.add_button("« Back to slots")        # 3
        f.add_button("« Back to player")       # 4

        def on_pick(pl, btn_idx):
            if btn_idx == 0:  # Take
                dst = get_inventory(pl)
                if not dst:
                    pl.send_message("§cCan't access your inventory.")
                    return self._open_container(pl, target, which)
                item_now = get_item_from_slot(inv, slot_idx)
                if not item_now or is_air(item_now):
                    pl.send_message("§7Item no longer there.")
                    return self._open_container(pl, target, which)
                if add_item(dst, item_now):
                    set_item_in_slot(inv, slot_idx, None)
                    pl.send_message("§aItem moved to your inventory.")
                else:
                    pl.send_message("§cYour inventory is full.")
                return self._open_container(pl, target, which)

            if btn_idx == 1:  # Copy
                dst = get_inventory(pl)
                if not dst:
                    pl.send_message("§cCan't access your inventory.")
                    return self._open_container(pl, target, which)
                item_now = get_item_from_slot(inv, slot_idx)
                if not item_now or is_air(item_now):
                    pl.send_message("§7Item no longer there.")
                    return self._open_container(pl, target, which)
                if add_item(dst, item_now):
                    pl.send_message("§aA copy was added to your inventory.")
                else:
                    pl.send_message("§cYour inventory is full.")
                return self._open_container(pl, target, which)

            if btn_idx == 2:  # Remove
                item_now = get_item_from_slot(inv, slot_idx)
                if not item_now or is_air(item_now):
                    pl.send_message("§7Nothing to remove.")
                else:
                    if set_item_in_slot(inv, slot_idx, None):
                        pl.send_message("§aSlot cleared.")
                    else:
                        pl.send_message("§cFailed to clear that slot on this build.")
                return self._open_container(pl, target, which)

            if btn_idx == 3:
                return self._open_container(pl, target, which)
            if btn_idx == 4:
                return self._inspect_online_player(pl, target)

        f.on_submit = on_pick
        viewer.send_form(f)

    # ──────────────────────────────────────────────────────────────────────
    # CHEST VIEW + ACTIONS (Two-Phase: visual chest → item action picker)
    # ──────────────────────────────────────────────────────────────────────

    def _show_chest_then_actions(self, viewer: Player, target: Player, which: str):
        """Show visual chest form with clickable slots.
        Clicking a slot shows item details + actions.
        Closing the chest shows the action picker."""
        if not CHEST_FORM_AVAILABLE:
            viewer.send_message("§cChest form display is not available.")
            return self._inspect_online_player(viewer, target)

        tname = player_name(target)
        if which == "inv":
            inv = get_inventory(target)
            title = f"{tname}'s Inventory"
            allow_armor = False
        else:
            inv = get_ender(target)
            title = f"{tname}'s Ender Chest"
            allow_armor = False

        if not inv:
            viewer.send_message("§cCan't read inventory on this build.")
            return self._inspect_online_player(viewer, target)

        # Build mapping: chest_slot -> inventory_slot
        chest_to_inv = {}
        chest = ChestForm(self, title, allow_armor)
        size = inv_size(inv)

        if which == "ender":
            for slot_idx in range(min(size, 27)):
                item = get_item_from_slot(inv, slot_idx)
                if item and not is_air(item):
                    self._add_item_to_chest(chest, item, slot_idx)
                    chest_to_inv[slot_idx] = slot_idx
        else:
            for slot_idx in range(size):
                item = get_item_from_slot(inv, slot_idx)
                if item and not is_air(item):
                    chest_slot = self._map_slot_to_chest(slot_idx, which)
                    if chest_slot is not None:
                        self._add_item_to_chest(chest, item, chest_slot)
                        chest_to_inv[chest_slot] = slot_idx

        # Track whether we handled a click (to avoid also triggering on_close action)
        click_handled = {"value": False}

        # When a slot is clicked, show item details + actions
        def on_slot_click(player, clicked_slot):
            click_handled["value"] = True
            inv_slot = chest_to_inv.get(clicked_slot)
            if inv_slot is None:
                # Clicked an empty slot, just reshow the chest
                return self._show_chest_then_actions(player, target, which)
            return self._chest_item_actions(player, target, inv, inv_slot, which)

        # When the chest is closed (not via slot click), show the action picker
        def on_chest_close(player):
            if not click_handled["value"]:
                self.server.scheduler.run_task(
                    self, lambda: self._chest_action_picker(viewer, target, which), delay=5
                )

        chest.on_submit = on_slot_click
        chest.on_close = on_chest_close
        chest.send_to(viewer)

    def _add_item_to_chest(self, chest, item, chest_slot: int):
        """Add an item to the chest form with rich lore (enchants, shulker contents, damage)"""
        try:
            item_type = str(item.type) if hasattr(item, 'type') else "minecraft:barrier"
            item_amount = getattr(item, 'amount', 1)

            # Display name
            display_name = item_display_name(item)

            # Build rich lore
            lore = build_rich_lore(item)

            # Build enchants dict for ChestForm (makes items glow)
            enchant_list = get_enchants_from_item(item)
            enchants = None
            if enchant_list:
                enchants = {}
                for ench_obj, elvl in enchant_list:
                    ench_id = ench_obj.id if hasattr(ench_obj, 'id') else str(ench_obj)
                    name = ENCHANT_NAMES.get(ench_id, ench_id.replace("minecraft:", "").replace("_", " ").title())
                    enchants[name] = elvl

            chest.set_slot(
                chest_slot,
                item_type,
                None,
                item_amount=item_amount,
                item_data=0,
                display_name=display_name,
                lore=lore if lore else None,
                enchants=enchants
            )
        except Exception as e:
            self.logger.warning(f"Failed to add item to chest slot {chest_slot}: {e}")

    def _chest_action_picker(self, viewer: Player, target: Player, which: str):
        """Phase 2: After chest view closes, show item picker + actions"""
        tname = player_name(target)
        label = "Inventory" if which == "inv" else "Ender Chest"

        if which == "inv":
            inv = get_inventory(target)
        else:
            inv = get_ender(target)

        if not inv:
            viewer.send_message("§cInventory no longer accessible.")
            return self._inspect_online_player(viewer, target)

        size = inv_size(inv)

        # Collect non-empty items
        items_list = []  # List of (slot_idx, item) tuples
        for i in range(size):
            it = get_item_from_slot(inv, i)
            if it and not is_air(it):
                items_list.append((i, it))

        if not items_list:
            viewer.send_message("§7No items found.")
            return self._inspect_online_player(viewer, target)

        form = ActionForm(
            title=f"§l{tname}'s {label} — Pick Item",
            content=f"§7Select an item to manage ({len(items_list)} items)"
        )

        for slot_idx, it in items_list:
            name = item_display_name(it)
            cnt = getattr(it, "amount", 1)
            item_type = str(it.type).lower()
            enchants = get_enchants_from_item(it)
            ench_tag = f" §b({len(enchants)} ench)" if enchants else ""

            if "shulker" in item_type:
                form.add_button(f"[{slot_idx}] §d📦 {name} ×{cnt}{ench_tag}")
            else:
                form.add_button(f"[{slot_idx}] {name} ×{cnt}{ench_tag}")

        form.add_button("§aView Chest Again")
        form.add_button("« Back to Player")

        def on_pick(pl, idx):
            if idx is None or idx < 0:
                return self._inspect_online_player(pl, target)
            if idx == len(items_list):  # View Chest Again
                return self._show_chest_then_actions(pl, target, which)
            if idx == len(items_list) + 1:  # Back to Player
                return self._inspect_online_player(pl, target)
            if idx < len(items_list):
                slot_idx, _ = items_list[idx]
                return self._chest_item_actions(pl, target, inv, slot_idx, which)
            return self._inspect_online_player(pl, target)

        form.on_submit = on_pick
        viewer.send_form(form)

    def _chest_item_actions(self, viewer: Player, target: Player, inv, slot_idx: int, which: str):
        """Show action form for a specific item selected from the chest action picker"""
        it = get_item_from_slot(inv, slot_idx)

        if not it or is_air(it):
            viewer.send_message("§7That slot is now empty.")
            return self._chest_action_picker(viewer, target, which)

        name = item_display_name(it)
        cnt = getattr(it, "amount", 1)
        item_type = str(it.type).lower()

        # Build detailed content
        content = f"§l{name}§r ×{cnt}\n§7Type: §f{item_type}\n§7Slot: §f{slot_idx}"

        # Enchantments
        enchants = get_enchants_from_item(it)
        if enchants:
            content += "\n\n§6Enchantments:"
            for ench_obj, elvl in enchants:
                content += f"\n  {enchant_display(ench_obj, elvl)}"

        # Damage
        damage = get_damage_from_item(it)
        if damage > 0:
            content += f"\n§7Damage: §c{damage}"

        # Repair cost and unbreakable
        try:
            meta = it.item_meta
            if meta is not None:
                if meta.has_repair_cost and meta.repair_cost > 0:
                    content += f"\n§7Repair Cost: §e{meta.repair_cost}"
                if meta.is_unbreakable:
                    content += "\n§9✦ Unbreakable"
        except Exception:
            pass

        # Shulker indicator
        if "shulker" in item_type:
            content += "\n\n§d📦 Shulker Box"
            content += "\n§7Contents can be viewed by placing the shulker in-game."

        f = ActionForm(title=f"§l{name}", content=content)
        f.add_button("§aTake (move to me)")    # 0
        f.add_button("§bCopy to me")           # 1
        f.add_button("§cDelete (clear slot)")  # 2
        f.add_button("« Pick another item")    # 3
        f.add_button("§aView Chest Again")     # 4

        def on_action(pl, btn_idx):
            if btn_idx == 0:  # Take
                dst = get_inventory(pl)
                if not dst:
                    pl.send_message("§cCan't access your inventory.")
                    return self._chest_action_picker(pl, target, which)
                item_now = get_item_from_slot(inv, slot_idx)
                if not item_now or is_air(item_now):
                    pl.send_message("§7Item no longer there.")
                    return self._chest_action_picker(pl, target, which)
                if add_item(dst, item_now):
                    set_item_in_slot(inv, slot_idx, None)
                    pl.send_message(f"§aMoved §f{name} ×{cnt} §ato your inventory.")
                else:
                    pl.send_message("§cYour inventory is full.")
                return self._chest_action_picker(pl, target, which)

            if btn_idx == 1:  # Copy
                dst = get_inventory(pl)
                if not dst:
                    pl.send_message("§cCan't access your inventory.")
                    return self._chest_action_picker(pl, target, which)
                item_now = get_item_from_slot(inv, slot_idx)
                if not item_now or is_air(item_now):
                    pl.send_message("§7Item no longer there.")
                    return self._chest_action_picker(pl, target, which)
                if add_item(dst, item_now):
                    pl.send_message(f"§aCopied §f{name} ×{cnt} §ato your inventory.")
                else:
                    pl.send_message("§cYour inventory is full.")
                return self._chest_action_picker(pl, target, which)

            if btn_idx == 2:  # Delete
                item_now = get_item_from_slot(inv, slot_idx)
                if not item_now or is_air(item_now):
                    pl.send_message("§7Nothing to remove.")
                else:
                    if set_item_in_slot(inv, slot_idx, None):
                        pl.send_message(f"§aDeleted §f{name} ×{cnt} §afrom slot {slot_idx}.")
                    else:
                        pl.send_message("§cFailed to clear that slot.")
                return self._chest_action_picker(pl, target, which)

            if btn_idx == 3:  # Pick another
                return self._chest_action_picker(pl, target, which)
            if btn_idx == 4:  # View chest again
                return self._show_chest_then_actions(pl, target, which)

        f.on_submit = on_action
        viewer.send_form(f)

    def _map_slot_to_chest(self, slot_idx: int, which: str) -> int:
        """Map inventory slot index to chest form slot"""
        if which == "ender":
            return slot_idx
        else:
            if 9 <= slot_idx <= 35:
                return slot_idx - 9  # Main inventory
            elif 0 <= slot_idx <= 8:
                return 27 + slot_idx  # Hotbar
            else:
                return None

    # ──────────────────────────────────────────────────────────────────────
    # OFFLINE PLAYER ENDER CHEST VIEWING (DATABASE-ONLY)
    # ──────────────────────────────────────────────────────────────────────

    def _pick_offline_player(self, viewer: Player):
        """Show text input to search for offline player"""
        if not hasattr(self, 'db') or not self.db:
            viewer.send_message("§cDatabase not available for offline player lookup.")
            return self.open(viewer)

        form = ModalForm(title="§lOffline Player Search")
        form.add_control(TextInput(
            label="Player Name",
            placeholder="Enter player name...",
            default_value=""
        ))

        def on_submit(pl, data):
            if data is None:
                return self.open(pl)
            # Normalize: data may arrive as a JSON string on some platforms
            if isinstance(data, str):
                try:
                    data = json.loads(data)
                    if not isinstance(data, list):
                        data = [data]
                except (json.JSONDecodeError, TypeError):
                    data = [data]
            search_name = data[0].strip() if data and len(data) > 0 else ""
            if not search_name:
                pl.send_message("§cPlease enter a player name.")
                return self._pick_offline_player(pl)
            return self._find_offline_player(pl, search_name)

        form.on_submit = on_submit
        viewer.send_form(form)

    def _find_offline_player(self, viewer: Player, search_name: str):
        """Find offline player by name from database"""
        if not hasattr(self, 'db') or not self.db:
            viewer.send_message("§cDatabase not available.")
            return self.open(viewer)

        try:
            users = self.db.search_users_by_name(search_name)
            if users:
                if len(users) == 1:
                    return self._show_offline_enderchest_from_db(viewer, users[0])
                else:
                    return self._show_user_selection(viewer, users, search_name)

            viewer.send_message(f"§cNo player found matching '§e{search_name}§c' in database.")
            viewer.send_message("§7Players must have logged out at least once since this plugin was installed.")
            return self._pick_offline_player(viewer)
        except Exception as e:
            self.logger.error(f"Database search failed: {e}")
            viewer.send_message(f"§cDatabase search error: {e}")
            return self._pick_offline_player(viewer)

    def _show_user_selection(self, viewer: Player, users: list, search_name: str):
        """Show selection menu for multiple user matches"""
        form = ActionForm(
            title="§lMultiple Matches Found",
            content=f"§7Found {len(users)} players matching '§e{search_name}§7'"
        )
        for user in users:
            form.add_button(f"§7{user.name}")
        form.add_button("« Search Again")

        def on_submit(pl, idx):
            if idx is None or idx >= len(users):
                return self._pick_offline_player(pl)
            return self._show_offline_enderchest_from_db(pl, users[idx])

        form.on_submit = on_submit
        viewer.send_form(form)

    def _show_offline_enderchest_from_db(self, viewer: Player, user):
        """Display offline player's ender chest from database - choose view"""
        form = ActionForm(
            title=f"§l{user.name}'s Ender Chest (Offline)",
            content=(
                "§eList View§r - Text list with copy actions\n"
                "§bChest View§r - Visual chest display + actions"
            )
        )
        form.add_button("§eList View")  # 0

        if CHEST_FORM_AVAILABLE:
            form.add_button("§bChest View + Actions")  # 1
            form.add_button("« Back")                   # 2
        else:
            form.add_button("« Back")                   # 1

        def pick(pl, idx):
            if idx == 0:
                return self._show_offline_enderchest_list_db(pl, user)
            elif idx == 1:
                if CHEST_FORM_AVAILABLE:
                    return self._show_offline_chest_then_actions(pl, user)
                else:
                    return self._pick_offline_player(pl)
            else:
                return self._pick_offline_player(pl)

        form.on_submit = pick
        viewer.send_form(form)

    # ──────────────────────────────────────────────────────────────────────
    # OFFLINE ENDER CHEST — LIST VIEW
    # ──────────────────────────────────────────────────────────────────────

    def _show_offline_enderchest_list_db(self, viewer: Player, user):
        """Show offline ender chest as list with copy actions (from database)"""
        try:
            ender_items = self.db.get_enderchest(user.xuid)

            if not ender_items:
                viewer.send_message(f"§c{user.name}'s ender chest is empty or data not found.")
                return self._show_offline_enderchest_from_db(viewer, user)

            form = ActionForm(
                title=f"§l{user.name}'s Ender Chest (Offline)",
                content="§7Click an item to manage it"
            )

            ender_items.sort(key=lambda x: x.get("slot", 0))

            for item_data in ender_items:
                info = get_item_display_info(item_data)
                slot = info["slot"]
                name = info["display_name"]
                amount = info["amount"]
                item_type = info["type"]
                enchants = info.get("enchants", {})
                ench_tag = f" §b({len(enchants)} ench)" if enchants else ""

                if "shulker" in item_type.lower():
                    contents = extract_shulker_contents(item_data)
                    count_str = f"§7({len(contents)} items)" if contents else "§7(empty)"
                    form.add_button(f"[{slot}] §d{name} ×{amount} {count_str}{ench_tag}")
                else:
                    form.add_button(f"[{slot}] {name} ×{amount}{ench_tag}")

            form.add_button("« Back")

            def on_select(pl, idx):
                if idx is None or idx >= len(ender_items):
                    return self._show_offline_enderchest_from_db(pl, user)
                selected_item = ender_items[idx]
                return self._offline_item_actions_db(pl, user, selected_item)

            form.on_submit = on_select
            viewer.send_form(form)

        except Exception as e:
            self.logger.error(f"Error reading offline player data for {user.name}: {e}")
            viewer.send_message(f"§cFailed to load {user.name}'s ender chest data.")
            return self._pick_offline_player(viewer)

    def _offline_item_actions_db(self, viewer: Player, user, item_data: dict):
        """Show actions for an offline ender chest item (from database)"""
        info = get_item_display_info(item_data)
        item_type = info["type"]
        item_count = info["amount"]
        display_name = info["display_name"]

        content = f"§l{display_name}§r ×{item_count}\n§7Type: §f{item_type}"

        # Enchantments (from DB — uses legacy numeric IDs)
        enchants = info.get("enchants", {})
        if enchants:
            content += "\n\n§6Enchantments:"
            for ench_key, lvl in enchants.items():
                try:
                    eid = int(ench_key.replace("Enchantment ", ""))
                    ench_str_id = _LEGACY_ENCHANT_IDS.get(eid, f"minecraft:unknown_{eid}")
                except (ValueError, AttributeError):
                    ench_str_id = str(ench_key)
                content += f"\n  {enchant_display(ench_str_id, lvl)}"

        # Damage
        damage = info.get("damage", 0)
        if damage > 0:
            content += f"\n§7Damage: §c{damage}"

        # Shulker contents
        if "shulker" in item_type.lower():
            contents = extract_shulker_contents(item_data)
            if contents:
                content += f"\n\n§dShulker Contents ({len(contents)} items):"
                for entry in contents[:10]:
                    content += f"\n§7• {entry['name']} ×{entry['count']}"
                if len(contents) > 10:
                    content += f"\n§8... and {len(contents) - 10} more"

        content += "\n\n§eWhat would you like to do?"

        form = ActionForm(title=f"§l{display_name}", content=content)
        form.add_button("§aCopy to My Inventory")
        form.add_button("« Back")

        def on_action(pl, idx):
            if idx == 0:
                return self._copy_offline_item_db(pl, user, item_data)
            else:
                return self._show_offline_enderchest_list_db(pl, user)

        form.on_submit = on_action
        viewer.send_form(form)

    def _copy_offline_item_db(self, viewer: Player, user, item_data: dict):
        """Copy an offline ender chest item to viewer's inventory using full NBT deserialization"""
        try:
            item = deserialize_item(item_data)
            if not item:
                viewer.send_message("§cFailed to recreate this item.")
                return self._show_offline_enderchest_list_db(viewer, user)

            viewer_inv = get_inventory(viewer)
            if not viewer_inv:
                viewer.send_message("§cCan't access your inventory.")
                return self._show_offline_enderchest_list_db(viewer, user)

            if add_item(viewer_inv, item):
                info = get_item_display_info(item_data)
                viewer.send_message(f"§aCopied §f{info['display_name']} ×{info['amount']} §ato your inventory!")
            else:
                viewer.send_message("§cYour inventory is full.")

            return self._show_offline_enderchest_list_db(viewer, user)

        except Exception as e:
            self.logger.error(f"Failed to copy offline item: {e}")
            viewer.send_message("§cFailed to copy item to your inventory.")
            return self._show_offline_enderchest_list_db(viewer, user)

    # ──────────────────────────────────────────────────────────────────────
    # OFFLINE ENDER CHEST — CHEST VIEW + ACTIONS
    # ──────────────────────────────────────────────────────────────────────

    def _show_offline_chest_then_actions(self, viewer: Player, user):
        """Phase 1: Show offline ender chest as visual ChestForm with rich lore.
        Phase 2: After chest closes, show action picker."""
        if not CHEST_FORM_AVAILABLE:
            viewer.send_message("§cChestForm is not available.")
            return self._show_offline_enderchest_from_db(viewer, user)

        try:
            ender_items = self.db.get_enderchest(user.xuid)

            if not ender_items:
                viewer.send_message(f"§c{user.name}'s ender chest is empty or data not found.")
                return self._show_offline_enderchest_from_db(viewer, user)

            chest = ChestForm(self, f"{user.name}'s Ender Chest (Offline)", False)

            for item_data in ender_items:
                slot = item_data.get("slot", -1)
                if slot < 0 or slot > 26:
                    continue

                info = get_item_display_info(item_data)
                item_type = info["type"]
                item_count = info["amount"]
                display_name = info["display_name"]

                # Build rich lore from DB data
                lore = build_rich_lore_from_db(item_data)

                # Build enchants dict for ChestForm glow
                enchants = info.get("enchants", {})
                enchants_dict = None
                if enchants:
                    enchants_dict = {}
                    for ench_key, lvl in enchants.items():
                        try:
                            eid = int(ench_key.replace("Enchantment ", ""))
                            name = ENCHANT_NAMES.get(eid, ench_key)
                        except (ValueError, AttributeError):
                            name = ench_key
                        enchants_dict[name] = lvl

                try:
                    chest.set_slot(
                        slot,
                        item_type,
                        None,
                        item_amount=item_count,
                        item_data=0,
                        display_name=display_name,
                        lore=lore if lore else None,
                        enchants=enchants_dict
                    )
                except Exception as e:
                    self.logger.warning(f"Failed to set offline ender chest slot {slot}: {e}")

            # Build mapping: chest_slot -> item_data for click handling
            slot_to_item = {}
            for item_data in ender_items:
                slot = item_data.get("slot", -1)
                if 0 <= slot <= 26:
                    slot_to_item[slot] = item_data

            # Track whether we handled a click
            click_handled = {"value": False}

            # When a slot is clicked, show item details + actions
            def on_slot_click(player, clicked_slot):
                click_handled["value"] = True
                item_data = slot_to_item.get(clicked_slot)
                if item_data is None:
                    return self._show_offline_chest_then_actions(player, user)
                return self._offline_item_detail(player, user, item_data, ender_items)

            # When the chest is closed (not via click), show the action picker
            def on_chest_close(player):
                if not click_handled["value"]:
                    self.server.scheduler.run_task(
                        self, lambda: self._offline_chest_action_picker(viewer, user, ender_items), delay=5
                    )

            chest.on_submit = on_slot_click
            chest.on_close = on_chest_close
            chest.send_to(viewer)

        except Exception as e:
            self.logger.error(f"Error displaying offline ender chest for {user.name}: {e}")
            viewer.send_message(f"§cFailed to display {user.name}'s ender chest.")
            return self._show_offline_enderchest_from_db(viewer, user)

    def _offline_chest_action_picker(self, viewer: Player, user, ender_items: list):
        """Phase 2: Pick an item from the offline ender chest to act on"""
        form = ActionForm(
            title=f"§l{user.name}'s Ender Chest — Pick Item",
            content=f"§7Select an item to copy ({len(ender_items)} items)"
        )

        ender_items.sort(key=lambda x: x.get("slot", 0))

        for item_data in ender_items:
            info = get_item_display_info(item_data)
            slot = info["slot"]
            name = info["display_name"]
            amount = info["amount"]
            item_type = info["type"]
            enchants = info.get("enchants", {})
            ench_tag = f" §b({len(enchants)} ench)" if enchants else ""

            if "shulker" in item_type.lower():
                contents = extract_shulker_contents(item_data)
                count_str = f"§7({len(contents)} items)" if contents else "§7(empty)"
                form.add_button(f"[{slot}] §d{name} ×{amount} {count_str}{ench_tag}")
            else:
                form.add_button(f"[{slot}] {name} ×{amount}{ench_tag}")

        form.add_button("§aView Chest Again")
        form.add_button("« Back")

        def on_pick(pl, idx):
            if idx is None or idx < 0:
                return self._show_offline_enderchest_from_db(pl, user)
            if idx == len(ender_items):  # View chest again
                return self._show_offline_chest_then_actions(pl, user)
            if idx == len(ender_items) + 1:  # Back
                return self._show_offline_enderchest_from_db(pl, user)
            if idx < len(ender_items):
                return self._offline_chest_item_actions(pl, user, ender_items[idx], ender_items)
            return self._show_offline_enderchest_from_db(pl, user)

        form.on_submit = on_pick
        viewer.send_form(form)

    def _offline_item_detail(self, viewer: Player, user, item_data: dict, all_items: list):
        """Bridge method for ChestForm slot click -> item detail view"""
        return self._offline_chest_item_actions(viewer, user, item_data, all_items)

    def _offline_chest_item_actions(self, viewer: Player, user, item_data: dict, all_items: list):
        """Show detailed info + copy action for an offline item from chest view"""
        info = get_item_display_info(item_data)
        item_type = info["type"]
        display_name = info["display_name"]
        amount = info["amount"]

        content = f"§l{display_name}§r ×{amount}\n§7Type: §f{item_type}"

        # Enchantments (from DB — uses legacy numeric IDs)
        enchants = info.get("enchants", {})
        if enchants:
            content += "\n\n§6Enchantments:"
            for ench_key, lvl in enchants.items():
                try:
                    eid = int(ench_key.replace("Enchantment ", ""))
                    ench_str_id = _LEGACY_ENCHANT_IDS.get(eid, f"minecraft:unknown_{eid}")
                except (ValueError, AttributeError):
                    ench_str_id = str(ench_key)
                content += f"\n  {enchant_display(ench_str_id, lvl)}"

        # Damage
        damage = info.get("damage", 0)
        if damage > 0:
            content += f"\n§7Damage: §c{damage}"

        # Shulker contents
        if "shulker" in item_type.lower():
            contents = extract_shulker_contents(item_data)
            if contents:
                content += f"\n\n§dShulker Contents ({len(contents)} items):"
                for entry in contents[:10]:
                    content += f"\n§7• {entry['name']} ×{entry['count']}"
                if len(contents) > 10:
                    content += f"\n§8... and {len(contents) - 10} more"

        form = ActionForm(title=f"§l{display_name}", content=content)
        form.add_button("§aCopy to My Inventory")  # 0
        form.add_button("« Pick another item")      # 1
        form.add_button("§aView Chest Again")        # 2

        def on_action(pl, idx):
            if idx == 0:
                self._copy_offline_item_db(pl, user, item_data)
                return self._offline_chest_action_picker(pl, user, all_items)
            elif idx == 1:
                return self._offline_chest_action_picker(pl, user, all_items)
            elif idx == 2:
                return self._show_offline_chest_then_actions(pl, user)
            else:
                return self._offline_chest_action_picker(pl, user, all_items)

        form.on_submit = on_action
        viewer.send_form(form)