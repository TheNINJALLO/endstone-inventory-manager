from endstone.plugin import Plugin
from endstone.command import Command, CommandSender
from endstone.event import event_handler, PlayerJoinEvent, PlayerQuitEvent
from endstone.form import ActionForm, ModalForm, TextInput
from endstone import Player
from endstone.inventory import ItemStack
import time
import json
from .db_util import (
    InventoryDB, deserialize_item, serialize_item,
)
from endstone_inventoryui import Menu, MenuType, MenuTransaction, MenuTransactionResult

# ──────────────────────────────────────────────────────────────────────
# HELPER FUNCTIONS
# ──────────────────────────────────────────────────────────────────────

def online_players(plugin: Plugin):
    """Get all online players from the server"""
    return plugin.server.online_players


def player_name(player: Player) -> str:
    """Get player's display name"""
    return player.name


def get_inventory(player: Player):
    """Get player's main inventory"""
    try:
        return player.inventory
    except AttributeError:
        return None


def get_ender(player: Player):
    """Get player's ender chest inventory"""
    try:
        return player.ender_chest
    except AttributeError:
        return None


# ──────────────────────────────────────────────────────────────────────
# MAIN PLUGIN CLASS
# ──────────────────────────────────────────────────────────────────────

class InventoryManagerPlugin(Plugin):
    api_version = "0.5"

    commands = {
        "manageinv": {
            "description": "Open inventory management interface",
            "usages": ["/manageinv"],
            "permissions": ["inventory_manager.use"]
        }
    }

    permissions = {
        "inventory_manager.use": {
            "description": "Allows using the inventory manager",
            "default": "op"
        }
    }

    def on_enable(self) -> None:
        """Called when plugin is enabled"""
        self.logger.info("Inventory Manager Plugin v1.0.8 enabled!")

        # Initialize database
        try:
            self.db = InventoryDB()
            self.logger.info("Database initialized successfully")
        except Exception as e:
            self.logger.error(f"Failed to initialize database: {e}")
            self.db = None

        self.logger.info("Visual display is ENABLED (InventoryUI)")
        self.register_events(self)

    def on_disable(self) -> None:
        """Called when plugin is disabled"""
        if hasattr(self, 'db') and self.db:
            try:
                self.db.close()
                self.logger.info("Database connection closed")
            except Exception as e:
                self.logger.error(f"Error closing database: {e}")

        self.logger.info("Inventory Manager Plugin disabled!")

    def on_command(self, sender: CommandSender, command: Command, args: list[str]) -> bool:
        """Handle commands"""
        if command.name == "manageinv":
            if not isinstance(sender, Player):
                sender.send_error_message("This command can only be used by players!")
                return True
            
            if not sender.has_permission("inventory_manager.use"):
                sender.send_error_message("§cYou don't have permission to use this command!")
                return True
            
            self.open(sender)
            return True
        
        return False

    # ──────────────────────────────────────────────────────────────────────
    # EVENT HANDLERS
    # ──────────────────────────────────────────────────────────────────────

    @event_handler
    def on_player_join(self, event: PlayerJoinEvent):
        """Handle player join - save user info to database"""
        if not hasattr(self, 'db') or not self.db:
            return

        try:
            player = event.player
            join_time = int(time.time())
            self.db.save_user(player, join_time)
            self.logger.debug(f"Saved user info for {player.name} (XUID: {player.xuid})")
        except Exception as e:
            self.logger.error(f"Failed to save user info on join: {e}")

    @event_handler
    def on_player_quit(self, event: PlayerQuitEvent):
        """Handle player quit - save inventory and ender chest to database"""
        if not hasattr(self, 'db') or not self.db:
            return

        try:
            player = event.player
            leave_time = int(time.time())

            self.db.update_user_leave_time(player.xuid, leave_time)
            self.db.save_inventory(player)
            self.logger.debug(f"Saved inventory for {player.name}")
            self.db.save_enderchest(player)
            self.logger.debug(f"Saved ender chest for {player.name}")

        except Exception as e:
            self.logger.error(f"Failed to save player data on quit: {e}")

    # ──────────────────────────────────────────────────────────────────────
    # MAIN MENU
    # ──────────────────────────────────────────────────────────────────────
    
    def open(self, player: Player):
        """Open the main inventory manager menu"""
        form = ActionForm(
            title="§l§6Inventory Manager",
            content="§7Manage player inventories"
        )
        form.add_button("§aOnline Players")
        form.add_button("§eOffline Players")
        form.add_button("§cClose")

        def on_submit(pl, idx):
            if idx == 0:
                return self._pick_online_player(pl)
            elif idx == 1:
                return self._pick_offline_player(pl)

        form.on_submit = on_submit
        player.send_form(form)

    # ──────────────────────────────────────────────────────────────────────
    # ONLINE INVENTORIES FLOW
    # ──────────────────────────────────────────────────────────────────────
    def _pick_online_player(self, p: Player):
        opls = online_players(self)
        names = [player_name(pl) for pl in opls]

        if not names:
            p.send_message("§7No players online.")
            return self.open(p)

        form = ActionForm(title="§lOnline Players", content="Pick a player")
        for n in names: form.add_button(n)
        form.add_button("Back")

        def on_submit(pl, idx):
            if idx is None or idx < 0 or idx >= len(names):
                return self.open(pl)
            target = None
            for live in online_players(self):
                if player_name(live) == names[idx]:
                    target = live; break
            if not target:
                pl.send_message("§7Player went offline.")
                return self._pick_online_player(pl)
            return self._inspect_online_player(pl, target)
        form.on_submit = on_submit
        p.send_form(form)

    def _inspect_online_player(self, viewer: Player, target: Player):
        """Main inspection menu - choose between Inventory or Ender Chest"""
        tname = player_name(target)
        form = ActionForm(
            title=f"§lInspect: {tname}",
            content="Choose what to inspect:"
        )
        form.add_button("§6Inventory")       # 0
        form.add_button("§dEnder Chest")     # 1
        form.add_button("Back")              # 2

        def pick(pl, idx):
            if idx == 0:
                return self._open_online_inventory_ui(pl, target)
            elif idx == 1:
                return self._open_online_enderchest_ui(pl, target)
            else:
                return self._pick_online_player(pl)

        form.on_submit = pick
        viewer.send_form(form)

    def _open_online_inventory_ui(self, viewer: Player, target: Player):
        """Open target player's inventory as interactive Menu using endstone-inventoryui"""
        tname = player_name(target)
        menu = Menu(MenuType.DOUBLE_CHEST, f"{tname}'s Inventory")

        # 1. Populate main inventory slots (0 to 35)
        for i in range(36):
            item = target.inventory.get_item(i)
            if item and str(item.type) != "minecraft:air":
                menu.inventory.set_item(i, item)

        # 2. Add divider panes in slots 36-44 and 50-53
        divider = ItemStack("minecraft:gray_stained_glass_pane", 1)
        try:
            meta = divider.item_meta
            if meta:
                meta.display_name = "§r§8Divider"
                divider.set_item_meta(meta)
        except Exception:
            pass

        divider_slots = list(range(36, 45)) + list(range(50, 54))
        for slot in divider_slots:
            menu.inventory.set_item(slot, divider)

        # 3. Populate armor and offhand slots (45 to 49)
        helm = target.inventory.helmet
        if helm and str(helm.type) != "minecraft:air":
            menu.inventory.set_item(45, helm)
        chest = target.inventory.chestplate
        if chest and str(chest.type) != "minecraft:air":
            menu.inventory.set_item(46, chest)
        legs = target.inventory.leggings
        if legs and str(legs.type) != "minecraft:air":
            menu.inventory.set_item(47, legs)
        boots = target.inventory.boots
        if boots and str(boots.type) != "minecraft:air":
            menu.inventory.set_item(48, boots)
        offhand = target.inventory.item_in_off_hand
        if offhand and str(offhand.type) != "minecraft:air":
            menu.inventory.set_item(49, offhand)

        # 4. Listeners
        def on_transaction(tr: MenuTransaction) -> MenuTransactionResult:
            if tr.slot in divider_slots:
                return tr.discard()
            
            # Sync live target inventory in delayed task
            self.server.scheduler.run_task(
                self,
                lambda: self._sync_online_inventory(target, menu),
                delay=1
            )
            return tr.proceed()

        def on_close(closed_player: Player) -> None:
            self._sync_online_inventory(target, menu)
            closed_player.send_message(f"§aSaved and closed {tname}'s inventory.")

        menu.set_listener(on_transaction)
        menu.set_close_listener(on_close)
        menu.send_to(viewer)

    def _sync_online_inventory(self, target: Player, menu: Menu):
        try:
            # Main inventory slots 0-35
            for i in range(36):
                gui_item = menu.inventory.get_item(i)
                if gui_item is None or str(gui_item.type) == "minecraft:air":
                    target.inventory.set_item(i, None)
                else:
                    target.inventory.set_item(i, gui_item)

            # Armor and Offhand slots
            helm = menu.inventory.get_item(45)
            target.inventory.helmet = None if (helm is None or str(helm.type) == "minecraft:air") else helm
            chest = menu.inventory.get_item(46)
            target.inventory.chestplate = None if (chest is None or str(chest.type) == "minecraft:air") else chest
            legs = menu.inventory.get_item(47)
            target.inventory.leggings = None if (legs is None or str(legs.type) == "minecraft:air") else legs
            boots = menu.inventory.get_item(48)
            target.inventory.boots = None if (boots is None or str(boots.type) == "minecraft:air") else boots
            offhand = menu.inventory.get_item(49)
            target.inventory.item_in_off_hand = None if (offhand is None or str(offhand.type) == "minecraft:air") else offhand

            self.db.save_inventory(target)
        except Exception as e:
            self.logger.error(f"Error syncing online inventory for {target.name}: {e}")

    def _open_online_enderchest_ui(self, viewer: Player, target: Player):
        """Open target player's ender chest as interactive Menu using endstone-inventoryui"""
        tname = player_name(target)
        menu = Menu(MenuType.CHEST, f"{tname}'s Ender Chest")

        for i in range(27):
            item = target.ender_chest.get_item(i)
            if item and str(item.type) != "minecraft:air":
                menu.inventory.set_item(i, item)

        def on_transaction(tr: MenuTransaction) -> MenuTransactionResult:
            self.server.scheduler.run_task(
                self,
                lambda: self._sync_online_enderchest(target, menu),
                delay=1
            )
            return tr.proceed()

        def on_close(closed_player: Player) -> None:
            self._sync_online_enderchest(target, menu)
            closed_player.send_message(f"§aSaved and closed {tname}'s ender chest.")

        menu.set_listener(on_transaction)
        menu.set_close_listener(on_close)
        menu.send_to(viewer)

    def _sync_online_enderchest(self, target: Player, menu: Menu):
        try:
            for i in range(27):
                gui_item = menu.inventory.get_item(i)
                if gui_item is None or str(gui_item.type) == "minecraft:air":
                    target.ender_chest.set_item(i, None)
                else:
                    target.ender_chest.set_item(i, gui_item)

            self.db.save_enderchest(target)
        except Exception as e:
            self.logger.error(f"Error syncing online ender chest for {target.name}: {e}")

    # ──────────────────────────────────────────────────────────────────────
    # OFFLINE INVENTORIES FLOW
    # ──────────────────────────────────────────────────────────────────────

    def _pick_offline_player(self, viewer: Player):
        """Show text input to search for offline player"""
        if not hasattr(self, 'db') or not self.db:
            viewer.send_message("§cDatabase not available for offline player lookup.")
            return self.open(viewer)

        # Create text input form
        form = ModalForm(
            title="§lOffline Player Search",
            controls=[
                TextInput(
                    label="Player Name",
                    placeholder="Enter player name...",
                    default_value=""
                )
            ]
        )

        def on_submit(pl, data):
            if data is None:
                # User cancelled
                return self.open(pl)

            player_name = data[0].strip() if data and len(data) > 0 else ""

            if not player_name or player_name == "":
                pl.send_message("§cPlease enter a player name.")
                return self._pick_offline_player(pl)

            return self._find_offline_player(pl, player_name)

        form.on_submit = on_submit
        viewer.send_form(form)

    def _find_offline_player(self, viewer: Player, search_name: str):
        """Find offline player by name from database"""
        if not hasattr(self, 'db') or not self.db:
            viewer.send_message("§cDatabase not available.")
            return self.open(viewer)

        try:
            users = self.db.search_users_by_name(search_name)
            if users:
                if len(users) == 1:
                    return self._inspect_offline_player(viewer, users[0])
                else:
                    return self._show_user_selection(viewer, users, search_name)

            viewer.send_message(f"§cNo player found matching '§e{search_name}§c' in database.")
            viewer.send_message("§7Note: Players must join at least once for offline viewing/editing.")
            return self._pick_offline_player(viewer)
        except Exception as e:
            self.logger.error(f"Database search failed: {e}")
            viewer.send_message(f"§cDatabase search error: {e}")
            return self._pick_offline_player(viewer)

    def _show_user_selection(self, viewer: Player, users: list, search_name: str):
        """Show selection menu for multiple user matches"""
        form = ActionForm(
            title="§lMultiple Matches Found",
            content=f"§7Found {len(users)} players matching '§e{search_name}§7'"
        )

        for user in users:
            form.add_button(f"§7{user.name}")

        form.add_button("« Search Again")

        def on_submit(pl, idx):
            if idx is None or idx >= len(users):
                return self._pick_offline_player(pl)

            user = users[idx]
            return self._inspect_offline_player(pl, user)

        form.on_submit = on_submit
        viewer.send_form(form)

    def _inspect_offline_player(self, viewer: Player, user):
        """Offline player menu - choose between Inventory or Ender Chest"""
        form = ActionForm(
            title=f"§lInspect Offline: {user.name}",
            content="Choose what to inspect (saves directly to DB):"
        )
        form.add_button("§6Inventory")       # 0
        form.add_button("§dEnder Chest")     # 1
        form.add_button("Back")              # 2

        def pick(pl, idx):
            if idx == 0:
                return self._open_offline_inventory_ui(pl, user)
            elif idx == 1:
                return self._open_offline_enderchest_ui(pl, user)
            else:
                return self._pick_offline_player(pl)

        form.on_submit = pick
        viewer.send_form(form)

    def _open_offline_inventory_ui(self, viewer: Player, user):
        """Open offline player's inventory as interactive Menu using endstone-inventoryui"""
        menu = Menu(MenuType.DOUBLE_CHEST, f"{user.name}'s Inventory (Offline)")

        # 1. Populate divider panes in slots 36-44 and 50-53
        divider = ItemStack("minecraft:gray_stained_glass_pane", 1)
        try:
            meta = divider.item_meta
            if meta:
                meta.display_name = "§r§8Divider"
                divider.set_item_meta(meta)
        except Exception:
            pass

        divider_slots = list(range(36, 45)) + list(range(50, 54))
        for slot in divider_slots:
            menu.inventory.set_item(slot, divider)

        # 2. Load and deserialize items from the SQLite database
        try:
            db_items = self.db.get_inventory(user.xuid)
            for it_data in db_items:
                item = deserialize_item(it_data)
                if not item:
                    continue
                slot = it_data.get("slot", 0)
                if 0 <= slot < 36:
                    menu.inventory.set_item(slot, item)
                elif slot == -1:
                    menu.inventory.set_item(45, item)
                elif slot == -2:
                    menu.inventory.set_item(46, item)
                elif slot == -3:
                    menu.inventory.set_item(47, item)
                elif slot == -4:
                    menu.inventory.set_item(48, item)
                elif slot == -5:
                    menu.inventory.set_item(49, item)
        except Exception as e:
            self.logger.error(f"Error loading offline inventory for {user.name}: {e}")

        # 3. Listeners
        def on_transaction(tr: MenuTransaction) -> MenuTransactionResult:
            if tr.slot in divider_slots:
                return tr.discard()
            
            # Sync offline database changes in delayed task
            self.server.scheduler.run_task(
                self,
                lambda: self._sync_offline_inventory(user, menu),
                delay=1
            )
            return tr.proceed()

        def on_close(closed_player: Player) -> None:
            self._sync_offline_inventory(user, menu)
            closed_player.send_message(f"§aSaved and closed offline player {user.name}'s inventory.")

        menu.set_listener(on_transaction)
        menu.set_close_listener(on_close)
        menu.send_to(viewer)

    def _sync_offline_inventory(self, user, menu: Menu):
        try:
            items = []
            # Main inventory slots 0-35
            for i in range(36):
                gui_item = menu.inventory.get_item(i)
                if gui_item and str(gui_item.type) != "minecraft:air":
                    items.append(serialize_item(gui_item, i, "slot"))
            
            # Armor and offhand map
            armor_map = {
                45: (-1, "helmet"),
                46: (-2, "chestplate"),
                47: (-3, "leggings"),
                48: (-4, "boots"),
                49: (-5, "item_in_off_hand")
            }
            for gui_slot, (db_slot, slot_type) in armor_map.items():
                gui_item = menu.inventory.get_item(gui_slot)
                if gui_item and str(gui_item.type) != "minecraft:air":
                    items.append(serialize_item(gui_item, db_slot, slot_type))

            items_json = json.dumps(items, ensure_ascii=False)
            with self.db._lock:
                self.db.cursor.execute("""
                    INSERT OR REPLACE INTO inventories_v2 (xuid, name, items_json)
                    VALUES (?, ?, ?)
                """, (user.xuid, user.name, items_json))
                self.db.conn.commit()
        except Exception as e:
            self.logger.error(f"Error saving offline inventory for {user.name}: {e}")

    def _open_offline_enderchest_ui(self, viewer: Player, user):
        """Open offline player's ender chest as interactive Menu using endstone-inventoryui"""
        menu = Menu(MenuType.CHEST, f"{user.name}'s Ender Chest (Offline)")

        try:
            db_items = self.db.get_enderchest(user.xuid)
            for it_data in db_items:
                item = deserialize_item(it_data)
                if not item:
                    continue
                slot = it_data.get("slot", 0)
                if 0 <= slot < 27:
                    menu.inventory.set_item(slot, item)
        except Exception as e:
            self.logger.error(f"Error loading offline ender chest for {user.name}: {e}")

        def on_transaction(tr: MenuTransaction) -> MenuTransactionResult:
            self.server.scheduler.run_task(
                self,
                lambda: self._sync_offline_enderchest(user, menu),
                delay=1
            )
            return tr.proceed()

        def on_close(closed_player: Player) -> None:
            self._sync_offline_enderchest(user, menu)
            closed_player.send_message(f"§aSaved and closed offline player {user.name}'s ender chest.")

        menu.set_listener(on_transaction)
        menu.set_close_listener(on_close)
        menu.send_to(viewer)

    def _sync_offline_enderchest(self, user, menu: Menu):
        try:
            items = []
            for i in range(27):
                gui_item = menu.inventory.get_item(i)
                if gui_item and str(gui_item.type) != "minecraft:air":
                    items.append(serialize_item(gui_item, i, "slot"))

            items_json = json.dumps(items, ensure_ascii=False)
            with self.db._lock:
                self.db.cursor.execute("""
                    INSERT OR REPLACE INTO ender_chests_v2 (xuid, name, items_json)
                    VALUES (?, ?, ?)
                """, (user.xuid, user.name, items_json))
                self.db.conn.commit()
        except Exception as e:
            self.logger.error(f"Error saving offline ender chest for {user.name}: {e}")